package SubwayPlanning;

import java.util.ArrayList;

public class Line {//��·��
	public String name;
	public ArrayList<String> station;//��·�е�վ��
	public void setName(String name) {
		this.name=name;
	}
	public String getName() {
		return this.name;
	}
	public void setStation(ArrayList<String> station) {
		this.station=station;
	}
	public ArrayList<String> getStation() {
		return this.station;
	}
}
