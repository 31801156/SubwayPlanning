package SubwayPlanning;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
public class Writefile {
	//����ѯ���д��result�ļ�
	public void writefile(String s) throws IOException {
			FileWriter fileWritter = new FileWriter("C:\\Users\\���έ[0102sydxg\\Desktop\\result.txt",true);
			fileWritter.write(s);
			fileWritter.close();
}}
