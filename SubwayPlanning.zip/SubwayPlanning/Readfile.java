package SubwayPlanning;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;


public class Readfile {
	public ArrayList<String> readfile(String filename) throws IOException{
		ArrayList<String> list=new ArrayList<String>();
	    BufferedReader reader=null;
	    try{
	    	reader=new BufferedReader(new InputStreamReader(new FileInputStream(filename),"UTF-8"));//读取文件内容
	    	String tempString=null;  
	            int line=1;
	          //按行读取，存入list
	            while((tempString=reader.readLine())!=null){  
	            	list.add(tempString);
	                line++;  
	            }  
	            reader.close();  
	        }catch(FileNotFoundException fne){  
		    		System.out.println("****************\n文件不存在，读取失败！");
		    		System.exit(0);
	        } finally{  
	            if (reader!=null) {  
	                try {  
	                    reader.close();  
	                } catch (IOException e1) {  
	                }  
	            }  
	        } 
	    return list;//return
	    }  
	}

