package SubwayPlanning;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Clearfile {
	//���result�ļ�����д���µĲ�ѯ���
	public static void Clearfile() {
        File file =new File("C:\\Users\\���έ[0102sydxg\\Desktop\\result.txt");
        try {
            if(!file.exists()) {
                file.createNewFile();
            }
            FileWriter fileWriter =new FileWriter(file);
            fileWriter.write("");
            fileWriter.flush();
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
