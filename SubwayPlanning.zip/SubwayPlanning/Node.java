package SubwayPlanning;

import java.util.ArrayList;

public class Node{
	public String name;
	private int depth;//���
	public ArrayList<Node> parent=new ArrayList<Node>();//���׽ڵ�
	public ArrayList<Node> nearbyNode=new ArrayList<Node>();//����վ���б�
	public ArrayList<String> line=new ArrayList<String>();//���ڵ���·����
	public boolean flag=false;//��¼״̬
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name=name;
	}
	public int getDepth() {
		return this.depth;
	}
	public void setDepth(int depth) {
		this.depth=depth;
	}
	public boolean getFlag() {
		return this.flag;
	}
	public void setFlag(boolean flag) {
		this.flag=flag;
	}
}
